﻿using System;
using System.Collections.Generic;
using System.Text;

namespace entidades.modelo
{
    class Moto : Vehiculo
    {
        protected float _clilindrada;

        public Moto(string patente, EMarcas marca, byte cantRuedas, float cilindrada) : base(patente, cantRuedas, marca)
        {
            this._clilindrada = cilindrada;
        }

    }
}
