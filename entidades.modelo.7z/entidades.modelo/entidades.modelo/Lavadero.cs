﻿using System;
using System.Collections.Generic;
using System.Text;

namespace entidades.modelo
{
    class Lavadero
    {
        private List<Vehiculo> _vehiculos;
        static float _precioAuto;
        static float _precioCamion;
        static float _precioMoto;
        string _razonSocial;

         static Lavadero()
        {
            Random rm = new Random();
            _precioAuto = rm.Next(150, 566);
            _precioCamion = rm.Next(150, 566);
            _precioMoto = rm.Next(150, 566);
            if(_precioAuto == _precioCamion && _precioAuto == _precioMoto)
            {
                _precioCamion = rm.Next(150, 566);
                _precioMoto = rm.Next(150, 566);
            }
            if(_precioCamion == _precioMoto && _precioCamion == _precioAuto)
            {
                _precioAuto = rm.Next(150, 566);
            }

           
        }
        public Lavadero()
        {
            this._vehiculos = new List<Vehiculo>();
        }

        public Lavadero(string razonS):this()
        {
            this._razonSocial = razonS;
        }

        public string LavaderoToString {
            get
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("precios :moto" + _precioMoto + " auto :" + _precioAuto + " camion :" + _precioCamion);
                sb.AppendLine("Razon social :" + _razonSocial);
                foreach (Vehiculo item in this._vehiculos)
                {
                    sb.AppendLine(item.ToString());
                }
                return sb.ToString();
            }
        }

        public List<Vehiculo> Vehiculos { get { return this._vehiculos; } }

        public double MostrarTotalFacturado()
        {
            double valToral = 0;
            foreach(Vehiculo vel in this._vehiculos)
            {
                    if(vel is Auto)
                    {
                    valToral += _precioAuto;
                    }
                    else if(vel is Moto)
                    {
                    valToral += _precioMoto;
                    }
                    else
                    {
                    valToral += _precioCamion;
                    }
            }
            return valToral;
        }

        public double MostrarTotalFacturado(EVehiculo vehi)
        {
            double valTotal =0;
            foreach( Vehiculo item in this._vehiculos)
            {
                switch (vehi)
                {
                    case EVehiculo.auto:
                        if (item is Auto)
                        {
                            valTotal += _precioAuto;
                        }
                        break;
                    case EVehiculo.moto:
                        if (item is Moto)
                        {
                            valTotal += _precioMoto;
                        }
                        break;
                    case EVehiculo.camion:
                        if (item is Camion)
                        {
                            valTotal += _precioCamion;
                        }
                        break;
                    default:
                        break;
                }
            }
            return valTotal;
        }

        public static bool operator ==(Lavadero lav, Vehiculo vel)
        {
            bool vandera = false;
            foreach( Vehiculo item in lav._vehiculos )
            {
                if (item == vel)
                {
                    vandera = true;
                }
                return vandera;
            }
        }
    }
    
}
