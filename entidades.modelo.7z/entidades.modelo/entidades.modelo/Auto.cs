﻿using System;
using System.Collections.Generic;
using System.Text;

namespace entidades.modelo
{
    class Auto : Vehiculo
    {
        protected int _cantidadAsientos;

        public Auto(string patente,byte cantR, EMarcas marca, int asientos) : base(patente, cantR, marca)
        {
            this._cantidadAsientos = asientos;
        }
        public Auto(string patente, EMarcas marca, int asientos): this(patente,4,marca,asientos)
        {

        }

        protected virtual string _mostrar()
        {

            StringBuilder stringb = new StringBuilder();
            stringb.AppendLine(base.mostrar());
            stringb.AppendLine("cantidad de ruedas : " + this._cantRuedas);
            return stringb.ToString();
        }
    }
}
     
    

