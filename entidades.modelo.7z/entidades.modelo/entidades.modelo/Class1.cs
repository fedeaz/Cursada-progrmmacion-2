﻿using System;

namespace entidades.modelo
{
    public class Class1
    {
    }
}
