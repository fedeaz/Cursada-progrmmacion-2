﻿public enum EMarcas{
    Honda,
    Ford,
    Zanella,
    Scania,
    Iveco,
    Fiat,

}