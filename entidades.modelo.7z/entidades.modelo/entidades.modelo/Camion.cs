﻿using System;
using System.Collections.Generic;
using System.Text;

namespace entidades.modelo
{
    class Camion : Vehiculo
    {
        protected float _tara;

        public Camion(string patente, float tara, EMarcas marca,byte cantRuedas ):base(patente,6,marca)
        {
            this._tara = tara;
        }

        public Camion(Vehiculo vehiculo, float tara) : this (vehiculo.getPatente,tara,vehiculo.getMarca,vehiculo.getConRuedas)
        {
            
        }
        protected virtual string _mostrar()
        {

            StringBuilder stringb = new StringBuilder();
            stringb.AppendLine(base.mostrar());
            stringb.AppendLine("tara : " + this._tara);
            return stringb.ToString();
        }
    }
}
