﻿using System;
using System.Collections.Generic;
using System.Text;

namespace entidades.modelo
{
    class Vehiculo
    {
        protected string _patente;
        
        protected byte _cantRuedas;

        protected EMarcas _marca;

        public string getPatente { get { return this._patente; } }

        public byte getConRuedas { get { return this._cantRuedas; } set { this._cantRuedas = value; } }

        public EMarcas getMarca { get { return this._marca; } }

        protected virtual string mostrar()
        {

            StringBuilder stringb = new StringBuilder();
            stringb.AppendLine("marca : " + this._marca);
            stringb.AppendLine("patente : " + this._patente);
            stringb.AppendLine("cantidad de ruedas : " + this._cantRuedas);
            return stringb.ToString();
        }

        public Vehiculo(string pat, Byte cantR, EMarcas marc)
        {
            this._patente = pat;
            this._cantRuedas = cantR;
            this._marca = marc;
        }

        
        
        

        public override string ToString()
        {
            return this.mostrar();
        }

        public static bool operator ==(Vehiculo v1, Vehiculo v2)
        {
            bool retAux = false;
            if(v1._patente == v2._patente && v1._marca == v2._marca)
            {
                retAux = true;
            }
            return retAux;
        }

        public static bool operator !=(Vehiculo v1, Vehiculo v2)
        {
            return !(v1 == v2);
        }
    }
}
