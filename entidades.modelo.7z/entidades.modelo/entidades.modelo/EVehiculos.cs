﻿public enum EVehiculo
{
    auto,
    moto,
    camion,
}