﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Banana:Fruta
    {
        protected string _paisOrigen;
        public String Nombre
        {
            get { return "Banana"; }
        }

        public override bool TieneCarozo
        {
            get { return false; }
        }

        public Banana(string color, double peso, string PaisO):base(peso,color)
        {
            this._paisOrigen = PaisO;
        }

        protected override string FrutaToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine(base.FrutaToString());
            ret.AppendLine("Pais de Origen: " + this._paisOrigen);
            return this.FrutaToString();
        }
    }
}
