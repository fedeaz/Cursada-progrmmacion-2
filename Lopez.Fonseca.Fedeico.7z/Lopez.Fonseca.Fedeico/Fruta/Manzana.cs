﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Entidades;

namespace Entidades
{
    public class Manzana : Fruta ,ISerializar,IDeserializar
    {
        protected string _provinciaOrigen;
        
        public string Nombre
        {
          get { return "Manzana"; }
        }

        public override bool TieneCarozo
        {
          get { return true; }
        }

        public Manzana(string color ,double peso , string ProvinciaO)
           : base(peso, color)
        {
            this._provinciaOrigen = ProvinciaO;
        }

        protected override string FrutaToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine(base.FrutaToString());
            ret.AppendLine("Nombre: " + this.Nombre);
            
            return this.FrutaToString();
        }

        bool ISerializar.Xml(string a)
        {
        
                TextWriter escritor = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + a, true);
                XmlSerializer serializador = new XmlSerializer(typeof(Manzana));
                serializador.Serialize(escritor, this);
                escritor.Close();
                return true;
            
        }

        bool IDeserializar.Xml(string a,out Fruta f)
        {
            TextReader lector = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + a, true);
            XmlSerializer deserializador = new XmlSerializer(typeof(Manzana));
            deserializador.Deserialize(lector);
            Fruta fruta = 0;
            f = fruta;
            lector.Close();
            return true;
        }
    }
}
