﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Durazno : Fruta
    {
       
        protected int _cantPelusa;
        public string Nombre
        {
            get { return "Durazno"; }
        }

        public override bool TieneCarozo
        {
            get { return true; }
        }

        public Durazno( string color, double peso, int CantPelusa):base(peso,color)
        {
            this._cantPelusa = CantPelusa;
        }

        protected override string FrutaToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine(base.FrutaToString());
            ret.AppendLine("Cantidad de pelusa: " + this._cantPelusa);
            return this.FrutaToString();
        }

    }
}
