﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public delegate void CajonDelegado(object objeto, EventArgs evento);
    public class Cajon <T>
    {

        private int _capacidad;
        private List<T> _elementos;
        private double _precioUnitario;

        public List<T> Elementos
        {
            get { return this._elementos; }
        }
        //PrecioTotal:(sólo lectura) retorna el precio total del cajón (precio * cantidad de elementos).
        public double PrecioTotal
        {

            get
            {
                if (this._precioUnitario > 25)
                {
                    Manejador(this._precioUnitario, new EventArgs());
                    this.EventoPrecio = new CajonDelegado(Manejador);
                }
                return this._precioUnitario;

            }
        }

        public Cajon()
        {
            this._elementos = new List<T>();
        }
        public Cajon(int capacidad):this()
        {
            this._capacidad = capacidad;
        }
        public Cajon(double precio,int capaciodad):this(capaciodad)
        {
            this._precioUnitario = precio;
        }

        public override string ToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine("Capacidad del Cajon: " + this._capacidad);
            ret.AppendLine("Cantidad de Elemebtos: " + this._elementos.Count);
            ret.AppendLine("Precio Total: " + this._precioUnitario);
            foreach (T item in this._elementos)
            {
                ret.AppendLine(item.ToString());
            }

            return ret.ToString();
        }


        public static Cajon<T> operator +(Cajon<T> cajon, T fruta)
        {
            Cajon<T> cajonNuevo = new Cajon<T>();
            cajonNuevo = cajon;
            if (cajon._capacidad > cajon._elementos.Count)
            {
                cajon._elementos.Add(fruta);
            }
            else
            {
                throw new CajonLlenoException("La capacidad " + cajonNuevo._elementos.Count + " fue alcanzada");
            }

            return cajonNuevo;
        }

        public event CajonDelegado EventoPrecio;

        public static void Manejador(object objeto, EventArgs evento)
        {
            StreamWriter escritor = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + @"\archivo.txt", true);
            try
            {
                DateTime fecha = DateTime.Now;
                escritor.WriteLine(fecha.ToString() + " - Precio Total: " + ((double)objeto).ToString());
            }
            catch (Exception)
            {
            }
            escritor.Close();
        }

    }
}
