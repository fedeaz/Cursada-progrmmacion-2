﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cosas;

namespace ejercicioClase04
{
    class Program
    {
        static void Main(string[] args)
        {
            cosa algo = new cosa();
            //algo.cadena = "Pepe";
            //algo.fecha = DateTime.Now;
            //algo.numero = 20;
            algo.EstablecerValor("ALO");


            Console.WriteLine(cosa.mostrar(algo));
            Console.ReadLine();

        }
    }
}
