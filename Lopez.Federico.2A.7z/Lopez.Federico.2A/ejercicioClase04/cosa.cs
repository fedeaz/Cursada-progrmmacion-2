﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cosas
{
    class cosa
    {
        #region Atributos
        public string cadena;
        public double numero;
        public DateTime fecha;
        #endregion

        #region Metodos
        public static string mostrar(cosa a)
        {
            return a.mostrar();
        }

        private string mostrar()
        {
            return this.cadena + " " + this.fecha.ToLongDateString() + " " + this.numero.ToString();
        }
        #endregion
        public cosa()
        {
            this.cadena = "Sin valor";
            this.fecha = DateTime.Now;
            this.numero = 1.9;
        }

        public cosa(string c)
        {
            this.cadena = c;
            this.numero = 1.9;
            this.fecha = DateTime.Now;
        }


        /// <summary>
        /// Establece un valor
        /// </summary>
        /// <param name="a">Caden</param>
        public void EstablecerValor(string a)
        {
            this.cadena = a;
        }
        /// <summary>
        /// Establece un valor
        /// </summary>
        /// <param name="b">Numero</param>
        public void EstablecerValor(double b)
        {
            this.numero = b;
        }
        /// <summary>
        /// Establece un valor
        /// </summary>
        /// <param name="c">Fecha</param>
        public void EstablecerValor(DateTime c)
        {
            this.fecha = c;
        }
    }
}
