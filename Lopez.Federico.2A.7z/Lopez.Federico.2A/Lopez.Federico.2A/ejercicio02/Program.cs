﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio02
{
    class Program
    {
        static void Main(string[] args)
        {
            double numero;
            double cubo;
            double cuadrado;

            Console.WriteLine("ingrese un numero");
            numero = double.Parse(Console.ReadLine());

            if (numero > 0)
            {
                cuadrado = Math.Pow(numero, 2);
                cubo = Math.Pow(numero, 3);
                Console.WriteLine("el numero al cuadrado es {0} \n El numero al cubo es  {1}", cuadrado, cubo);
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("ERROR! al ingresar el numero");
                Console.ReadLine();
            }
        }
    }
}
