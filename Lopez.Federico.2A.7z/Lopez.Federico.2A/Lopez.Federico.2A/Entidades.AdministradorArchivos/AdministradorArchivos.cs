﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Entidades.AdministradorArchivos
{
    public static class AdministradorArchivos
    {

        public static bool Escribir(string path, string b)
        {
            bool flag = false;

            try
            {
                StreamWriter sw;
                using (sw = new StreamWriter(path, true))
                {
                    sw.WriteLine(b.ToString());
                }
            }
            catch (Exception)
            {
                flag = false;
            }
            return flag;
        }

        public static bool Leer(string path, out string b)
        {
            bool flag = false;
            string recu;
            b = " ";
            try
            {
                StreamReader sw;
                using (sw = new StreamReader(path, true))
                {
                    recu = sw.ReadToEnd();
                    b = recu;
                }
                flag = true;
            }
            catch (Exception)
            {
                flag = false;
            }
            return flag;
        }
    }
}
