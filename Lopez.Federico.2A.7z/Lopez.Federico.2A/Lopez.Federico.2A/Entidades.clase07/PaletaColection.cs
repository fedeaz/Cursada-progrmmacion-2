using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.clase07
{

    public class PaletasColection
    {
        //private Tempera[] _colores;
        List<Tempera> _colores = new List<Tempera>();

        private int _cantMaximaElementos;
        #region constructores
        private PaletasColection():this(5)
        {
        }

        private PaletasColection(int i)
        {
              this._cantMaximaElementos = i;
            //_colores = new Tempera[this._cantMaximaElementos];
        }
        #endregion

        private string mostrar()
        {
            string retorno = " ";
            retorno += this._cantMaximaElementos;
            retorno += " ";
            foreach (Tempera item in this._colores)
            {
              if(!object.Equals(item,null))
                retorno += "\r\n" + item;
            }

            return retorno;
        }

        public static explicit operator string(PaletasColection pal)
        {
            return pal.mostrar();
        }
        public static implicit operator PaletasColection(int i)
        {
            return new PaletasColection(i);
        }


        public static bool operator ==(PaletasColection pal, Tempera tep)
        {
            bool retorno = false;

            foreach (Tempera item in pal._colores)
            {
                if(!object.Equals(item,null))
                {
                    if(item == tep)
                    {
                        retorno = true;
                        break;
                    }
                }
            }
            return retorno;
        }

        public static bool operator !=(PaletasColection pal, Tempera tep)
        {
            return !(pal == tep);
        }


        private int ObtenerIndice()
        {
            int returnAux = -1;
            int i = 0;
            foreach(Tempera item in this._colores)
            {
                if(object.Equals(item, null))
                {
                    returnAux = i;
                    break;
                }
                i++;
            }
            return returnAux;
        }

        private int ObtenerIndice(Tempera temp)
        {
            int returnAux = -1;
            int contador = 0;
            foreach (Tempera item in this._colores)
            {
                //if (object.Equals(item, null))
                //{
                //    returnAux = i;
                //    break;
                //}
                //i++;
                if(object.Equals(item, null))
                {
                    if(temp == item)
                    {
                        returnAux = contador;
                        break;
                    }
                }
                contador++;
            }
            return returnAux;
        }


        public static PaletasColection operator +(PaletasColection pal,Tempera temp)
        {
            int indice = -1;
            
            if(pal._cantMaximaElementos > pal._colores.Count)
            { 
            if( pal == temp)
            {
                indice = pal.ObtenerIndice(temp);
                pal._colores[indice] += temp;
            }
            else
            {
                    //indice = pal.ObtenerIndice();
                    //if(indice > -1)
                    //{
                    //    pal._colores[indice] = temp;
                    //}
                    pal._colores.Add(temp);

            }
            }
            return pal;

        }

        public static PaletasColection operator -(PaletasColection pal,Tempera temp)
        {
            int indice = -1;
            sbyte aux1;
            sbyte aux2;
            if(pal == temp)
            {
                indice = pal.ObtenerIndice(temp);

                aux1 = (sbyte)pal._colores[indice];
                aux2 = (sbyte)temp;

                if(aux1-aux2 <= 0 )
                {
                    pal._colores[indice] = null;
                }
                else
                {
                    pal._colores[indice] += (sbyte)(aux2 * (-1));
                }
            }

            return pal;
        }

    public Tempera this[int indice]
    {
      get
      {
        if(indice >=this._colores.Count|| indice <0)
        {
          return null;
        }
        else
        {
          return this._colores[indice];
        }
      }
      set
      {
        if(indice >=0 && indice == this._colores.Count)
                {
                    this._colores[indice] = value;
                }
        else
                {
                    if(indice == this._colores.Count)
                    {
                        this._colores.Add(value);
                    }
                }
      }
    }


  }
}
