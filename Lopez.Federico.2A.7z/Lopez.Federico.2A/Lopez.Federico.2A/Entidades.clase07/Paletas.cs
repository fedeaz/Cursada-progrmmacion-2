using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.clase07
{

    public class Paletas
    {
        private Tempera[] _colores;
        private int _cantMaximaElementos;
        #region constructores
        private Paletas():this(5)
        {
        }

        private Paletas(int i)
        {
            this._cantMaximaElementos = i;
            _colores = new Tempera[this._cantMaximaElementos];
        }
        #endregion

        private string mostrar()
        {
            string retorno = " ";
            retorno += this._cantMaximaElementos;
            retorno += " ";
            foreach (Tempera item in this._colores)
            {
              if(!object.Equals(item,null))
                retorno += "\r\n" + item;
            }

            return retorno;
        }

        public static explicit operator string(Paletas pal)
        {
            return pal.mostrar();
        }
        public static implicit operator Paletas(int i)
        {
            return new Paletas(i);
        }


        public static bool operator ==(Paletas pal, Tempera tep)
        {
            bool retorno = false;

            foreach (Tempera item in pal._colores)
            {
                if(!object.Equals(item,null))
                {
                    if(item == tep)
                    {
                        retorno = true;
                        break;
                    }
                }
            }
            return retorno;
        }

        public static bool operator !=(Paletas pal, Tempera tep)
        {
            return !(pal == tep);
        }


        private int ObtenerIndice()
        {
            int returnAux = -1;
            int i = 0;
            foreach(Tempera item in this._colores)
            {
                if(object.Equals(item, null))
                {
                    returnAux = i;
                    break;
                }
                i++;
            }
            return returnAux;
        }

        private int ObtenerIndice(Tempera temp)
        {
            int returnAux = -1;
            int contador = 0;
            foreach (Tempera item in this._colores)
            {
                //if (object.Equals(item, null))
                //{
                //    returnAux = i;
                //    break;
                //}
                //i++;
                if(this._colores.GetValue(contador)!=null)
                {
                    if(temp == item)
                    {
                        returnAux = contador;
                        break;
                    }
                }
                contador++;
            }
            return returnAux;
        }


        public static Paletas operator +(Paletas pal,Tempera temp)
        {
            int indice = -1;
            
            if( pal == temp)
            {
                indice = pal.ObtenerIndice(temp);
                pal._colores[indice] += temp;
            }
            else
            {
                indice = pal.ObtenerIndice();
                if(indice > -1)
                {
                    pal._colores[indice] = temp;
                }

            }
            return pal;

        }

        public static Paletas operator -(Paletas pal,Tempera temp)
        {
            int indice = -1;
            sbyte aux1;
            sbyte aux2;
            if(pal == temp)
            {
                indice = pal.ObtenerIndice(temp);

                aux1 = (sbyte)pal._colores[indice];
                aux2 = (sbyte)temp;

                if(aux1-aux2 <= 0 )
                {
                    pal._colores[indice] = null;
                }
                else
                {
                    pal._colores[indice] += (sbyte)(aux2 * (-1));
                }
            }

            return pal;
        }

    public Tempera this[int indice]
    {
      get
      {
        if(indice >=this._colores.GetLength(0)|| indice <0)
        {
          return null;
        }
        else
        {
          return this._colores[indice];
        }
      }
      set
      {

      }
    }


  }
}
