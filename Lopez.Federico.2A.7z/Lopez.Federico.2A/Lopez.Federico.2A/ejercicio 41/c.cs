﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_41
{
    class c : b
    {

        public c() : base()
        {
            try
            {
                b.lanzar();
            }
            catch (DivideByZeroException e)
            {
                throw e;
            }
        }
    }
}
