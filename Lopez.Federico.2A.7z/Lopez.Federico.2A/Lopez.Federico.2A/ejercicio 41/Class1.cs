﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_41
{
    class Class1 : Exception
    {
        //public static Exception lanzar()
        //{
        //    throw new DivideByZeroException();

        //}

        //public Class1():base()
        //{
        //    try
        //    {
        //        Class1.lanzar();
        //    }
        //    catch (DivideByZeroException e)
        //    {
        //        Class1 nueva = new Class1(e);
        //        throw nueva;
        //    }
        //}
        

        //public Class1(Exception e):base()
        //{
        //    try
        //    {

        //    }
        //    catch()
        //    {

        //    }
        //}


    }
}
