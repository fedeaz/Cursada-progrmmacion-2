﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase10parte2
{
    public class Cocina
    {
        private int _codigo;
        private bool _esIndustrial;
        private double _precio;

        public int Codigo { get { return _codigo; } }

        public bool EsIndustrial { get { return _esIndustrial; } }

        public double Precio { get { return _precio; } }

        public Cocina(int codigo, bool esIndusstrial, double precio)
        {
             this._codigo = codigo ;
            this._esIndustrial = esIndusstrial;
            this._precio = precio;
        }

        public static bool operator ==(Cocina a, Cocina b)
        {
            if (a.Codigo == b.Codigo)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public static bool operator !=(Cocina a, Cocina b)
        {
            return !(a == b);
        }


        public override bool Equals(object obj)
        {
            bool flag = false;
            if (obj is Cocina && this == (Cocina)obj)
            {
                flag = true;
            }
            return flag;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(this.Codigo + " " + this.Precio + " " + this.EsIndustrial);

            return sb.ToString();
        }



    }

    }
