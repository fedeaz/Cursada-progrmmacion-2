﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Entidades.Clase10parte2
{
    public class DepositoDeCocinas
    {
        private int _CapacidadMaxima;
        private List<Cocina> _Lista;

        public DepositoDeCocinas(int capacidad)
        {
            this._Lista = new List<Cocina>(capacidad);
            _CapacidadMaxima = capacidad ;

        }

        public static bool operator +(DepositoDeCocinas d, Cocina b)
        {
            bool flag = false;
            if (d._Lista.Count < d._CapacidadMaxima)
            {
                d._Lista.Add(b);
                flag = true;
            }
            return flag;
        }

        private int GetIndice(Cocina a)
        {
            int contador = 0;
            int indice = -1;
            foreach (Cocina item in this._Lista)
            {
                if (item == a)
                {
                    indice = contador;
                    break;
                }
                contador++;

            }
            return indice;
        }

        public static bool operator -(DepositoDeCocinas d, Cocina a)
        {
            bool flag = false;
            int indice = d.GetIndice(a);

            if (indice != -1)
            {
                d._Lista.RemoveAt(indice);
                flag = true;
            }
            return flag;
        }

        public bool Agregar(Cocina a)
        {

            return this + a;
        }

        public bool Remover(Cocina a)
        {
            return this - a;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Capacidad : "+ this._CapacidadMaxima);
            foreach (Cocina item in this._Lista)
            {
                sb.AppendLine(item.ToString());

            }
            return sb.ToString();
        }

        public bool guardar(string path)
        {
            bool flag = false;

            try
            {
                StreamWriter sw;
                using (sw = new StreamWriter(path, true))
                {
                    sw.WriteLine(this.ToString());
                }
            }catch(Exception)
            {
                flag = false;
            }
            return flag;
            


        }

        public bool recuperar(string path)
        {
            bool flag = false;

            try
            {
                StreamReader sw;
                using (sw = new StreamReader(path, true))
                {
                   Console.WriteLine( sw.ReadLine());
                }
            }
            catch (Exception)
            {
                flag = false;
            }
            return flag;



        }

    }
}
