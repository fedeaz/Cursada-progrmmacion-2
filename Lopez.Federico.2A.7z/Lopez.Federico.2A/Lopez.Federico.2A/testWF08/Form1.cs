using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.clase07;
using System.Windows.Forms;


namespace testWF08
{
    public partial class Form1 : Form
    {
        Paletas _MiPaleta;
        public Form1()
        {
            InitializeComponent();
            this._MiPaleta = 5;
            this.groupBox1.Text = "Paleta de colores";
            this.textBox1.Multiline = true;
            this.button1.Text = "+";
            this.button2.Text = "-";
        }

   


        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void agregarPaletaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            
        }

        private void agregarPaletaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.groupBox1.Visible = true;
            this.agregarPaletaToolStripMenuItem.Enabled = false;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            frmTempera form = new frmTempera();
      DialogResult rta = form.ShowDialog();
      if(rta == DialogResult.OK)
      {
        this._MiPaleta += form.MiTempera;
        this.textBox1.Text = (string)this._MiPaleta;
      }
            


        }

        private void menuStrip1_ItemClicked_1(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

    private void button2_Click(object sender, EventArgs e)
    {
      string seleccion = textBox1.SelectedText;
      int contador = 0;
      foreach (string item in textBox1.Lines)
      {
        if(seleccion == item)
        {
          break;
        }

        contador++;
        contador = (contador - 2) / 2;
        seleccion += " " + contador.ToString();
        MessageBox.Show(seleccion);
      }

      Tempera test = new Tempera(4, ConsoleColor.Blue, "aaa");
      frmTempera fortemp = new frmTempera(test);
      DialogResult result = fortemp.ShowDialog();
      if(result == DialogResult.OK)
          {
        this._MiPaleta -= fortemp.MiTempera;
        this.textBox1.Text = (string)_MiPaleta;
          }

    }
  }
}
