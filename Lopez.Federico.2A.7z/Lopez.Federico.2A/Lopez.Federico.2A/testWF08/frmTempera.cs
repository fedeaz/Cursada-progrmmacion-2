using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.clase07;
using System.Windows.Forms;

namespace testWF08
{
    public partial class frmTempera : Form
    {
        public frmTempera()
        {
            InitializeComponent();

            foreach (ConsoleColor color in Enum.GetValues(typeof(ConsoleColor)))
            {
                this.comboBox1.Items.Add(color);
                this.comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            }

            comboBox1.SelectedItem = ConsoleColor.DarkBlue;

        }

        public frmTempera(Tempera temp):this()
        {
          this._miTempera = temp;
      MessageBox.Show("en constructor");
            this.comboBox1.SelectedItem = temp
          
        }


        private Tempera _miTempera;

        public Tempera MiTempera
        {
            get { return this._miTempera; }
        }




        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void frmTempera_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Tempera temp = new Tempera(sbyte.Parse(textBox2.Text), (ConsoleColor)this.comboBox1.SelectedItem,this.textBox1.Text);
            ConsoleColor color = (ConsoleColor)this.comboBox1.SelectedItem;
            sbyte cantidad = sbyte.Parse(this.textBox2.Text);
            string marca = this.textBox1.Text;
            this._miTempera = new Tempera(cantidad,color,marca);
             this.DialogResult = DialogResult.OK;
        }

    private void button2_Click(object sender, EventArgs e)
    {
        
    }
  }
}
