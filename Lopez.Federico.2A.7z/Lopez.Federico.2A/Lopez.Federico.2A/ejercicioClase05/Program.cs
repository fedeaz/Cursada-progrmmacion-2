﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicioClase05
{
    class Program
    {
        static void Main(string[] args)
        {
            Tinta tint = new Tinta();
            ConsoleColor color = ConsoleColor.Cyan;
            ETipoTinta tipo = ETipoTinta.China;



            //Console.WriteLine(Tinta.Mostrar(tint));
            //Console.ReadLine();

            Pluma plum = new Pluma("bic",15,tint);
            plum -= tint;

            Console.Write(plum);
            Console.ReadLine();

        }
    }
}
