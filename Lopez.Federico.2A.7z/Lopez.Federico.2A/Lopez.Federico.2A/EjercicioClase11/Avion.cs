﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase11
{
    public class Avion: Vehiculo , IAFIP, IARBA
    {
        protected double _velocidadMaxima;

        public Avion(double precio, double veMax):base(precio)
        {
            this._velocidadMaxima = veMax;
            
        }

        public double CalcularImpuesto()
        {
            return this._precio * 0.33;
            
        }

        double IAFIP.CalcularImpuesto()
        {
            return this._precio * 0.27;

        }



    }
}
