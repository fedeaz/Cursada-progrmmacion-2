﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EjercicioClase11;

namespace pruebaClase11
{
    class Program
    {
        static void Main(string[] args)
        {
            Deportivo nuevo = new Deportivo(1000,"lfe 120", 30);

            Avion prime = new Avion(4000, 600);

            Privado privi = new Privado(2000, 300, 1500);
            


            Console.Write("el precio del impuesto del deportivo es : ");
            nuevo.MostrarPrecio();
           
            Console.Write("el precio del impuesto del avion es : ");
            prime.MostrarPrecio();

            Console.WriteLine(((IAFIP)privi).CalcularImpuesto());
            Console.WriteLine(((IARBA)privi).CalcularImpuesto());

            Console.ReadLine();
        }
    }
}
