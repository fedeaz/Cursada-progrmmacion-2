﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace Entidades.Clase10.parte3
{
    public class Deposito<T>
    {

        private int _CapacidadMaxima;
        private List<T> _Lista;

        public Deposito(int capacidad)
        {
            this._Lista = new List<T>(capacidad);
            _CapacidadMaxima = capacidad;

        }

        public static bool operator +(Deposito<T> d, T b)
        {
            bool flag = false;
            if (d._Lista.Count < d._CapacidadMaxima)
            {
                d._Lista.Add(b);
                flag = true;
            }
            return flag;
        }

        private int GetIndice(T a)
        {
            int contador = 0;
            int indice = -1;
            foreach (T item in this._Lista)
            {
                if (item.Equals(a))
                {
                    indice = contador;
                    break;
                }
                contador++;

            }
            return indice;
        }

        public static bool operator -(Deposito<T> d, T a)
        {
            bool flag = false;
            int indice = d.GetIndice(a);

            if (indice != -1)
            {
                d._Lista.RemoveAt(indice);
                flag = true;
            }
            return flag;
        }

        public bool Agregar(T a)
        {

            return this + a;
        }

        public bool Remover(T a)
        {
            return this - a;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Capacidad : " + this._CapacidadMaxima);
            foreach (T item in this._Lista)
            {
                sb.AppendLine(item.ToString());

            }
            return sb.ToString();
        }

        public bool guardar(string path)
        {
            bool flag = false;

            try
            {
                StreamWriter sw;
                using (sw = new StreamWriter(path, true))
                {
                    sw.WriteLine(this.ToString());
                }
            }
            catch (Exception)
            {
                flag = false;
            }
            return flag;



        }
    }
}
