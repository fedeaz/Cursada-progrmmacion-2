﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.clase10
{
    public class Auto
    {
        private string _color;
        private string _marca;

        public string color { get {return _color; } }

        public string marca { get { return _marca; } }

        public Auto(string color, string marca)
        {
            color = _color;
            marca = _marca;
        }

        public static bool operator ==(Auto a, Auto b)
        {
            if (a._color == b._color && a._marca == b._marca)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public static bool operator !=(Auto a, Auto b)
        {
            return !(a == b);
        }

        public override bool Equals(object obj)
        {
            bool flag = false;
            if(obj is Auto && this ==(Auto)obj)
            {
                flag = true;
            }
            return flag;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(this.marca + " " + this.color);
            return sb.ToString();
        }


    }
}
