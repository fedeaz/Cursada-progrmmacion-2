﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.clase10
{
    public class DepositoDeAutos
    {
        private  int _CapacidadMaxima;
        private List<Auto> _Lista;

        public DepositoDeAutos(int capacidad)
        {
            this._Lista = new List<Auto>(capacidad);
             this._CapacidadMaxima = capacidad;

        }

        public static bool operator +(DepositoDeAutos d, Auto b)
        {
            bool flag = false;
            if(d._Lista.Count< d._CapacidadMaxima)
            {
                d._Lista.Add(b);
                flag = true;
            }
            return flag;
        }

        private int GetIndice(Auto a)
        {
            int contador = 0;
            int indice = -1;
            foreach (Auto item in this._Lista)
            {
                if(item == a)
                {
                    indice = contador;
                        break;
                }
                contador++;

            }
            return indice;
        }

        public static bool operator -(DepositoDeAutos d, Auto a)
        {
            bool flag = false;
            int indice = d.GetIndice(a);

            if(indice != -1)
            {
                d._Lista.RemoveAt(indice);
                flag = true;
            }
            return flag;
        }

        public bool Agregar(Auto a)
        {
            
            return  this + a;
        }

        public bool Remover(Auto a)
        {
            return this - a;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(this._CapacidadMaxima + "" + this._Lista);
            foreach (Auto item in this._Lista)
            {
                sb.AppendLine(item.ToString());

            }
            return sb.ToString();
        }


    }
}
