﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Clase10parte2;

namespace TestEntidades.clase10.parte2
{
    class Program
    {
        
            static void Main(string[] args)
            {
                Cocina c1 = new Cocina(111, false, 12300);
                Cocina c2 = new Cocina(112,  true, 15000);
                Cocina c3 = new Cocina(113,  false, 5600);
                DepositoDeCocinas dc = new DepositoDeCocinas(5);
                dc.Agregar(c1);
                dc.Agregar(c2);
                if (!(dc + c3))
                {
                    Console.WriteLine("No se pudo agregar el item!!!");
                }
                Console.WriteLine(dc);
                dc.Remover(c2);
                if (!(dc - c2))
                {
                    Console.WriteLine("No se pudo remover el item!!!");
                }
                Console.WriteLine(dc);
            dc.guardar(@"D:\Mis Documentos\archivo.txt");
                Console.ReadLine();
            }
        
    }
}
