﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using System.Xml.Serialization;

namespace BaseDeDatos
{
    public class Program
    {
        static void Main(string[] args)
        {
           List<Televisor> televiosres = new List<Televisor>();

        SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
            
            SqlCommand comando = new SqlCommand();
            comando.CommandText = "select * from Televisores";

            comando.CommandType = System.Data.CommandType.Text;//recibe un enum

            comando.Connection = conexion;//recibe un obj tipo sql conection

            //se conecta a la base de datos
            conexion.Open();

            SqlDataReader lector = comando.ExecuteReader();

            while (lector.Read())
            {
                Console.WriteLine(lector[0] + "-" + lector[1] + "-" + lector[2]+ "-" + lector[3]+ "-"+ lector[4]);
                televiosres.Add(new Televisor(lector.GetInt32(0), lector.GetInt32(3), lector.GetDouble(2), lector.GetString(1), lector.GetString(4)));
            }

            
            //se desconecta de la base de datos
            conexion.Close();

            XmlTextWriter escritor = new XmlTextWriter("televisores.xml",Encoding.UTF8);
            XmlTextReader L = new XmlTextReader("televisores.xml");



            XmlSerializer serializador = new XmlSerializer(typeof(List<Televisor>));

            serializador.Serialize(escritor, televiosres);

            escritor.Close();

            //serializador.Deserialize(L);
            List<Televisor> T = (List<Televisor>)serializador.Deserialize(L);
            L.Close();

            conexion.Open();

            lector = comando.ExecuteReader();

            //replica de base de datos en memoria:

            /*representacion en memoria de una tabla de base de datos*/
            DataTable table = new DataTable("televisores");

            //ahora cargamos el datatable con el contenido de la tabla de base de datos
            table.Load(lector);


            Televisor tvarg = new Televisor(12, 33, 65, "nextel", "mexico");

            Televisor tvNew = new Televisor(12, 30, 60, "Fanatic", "España");

            //if (!Televisor.modificar(tvNew))
            //{
            //    Console.WriteLine("no se pudo modificar");
            //}

            //if (!Televisor.borrar(tvNew))
            //{
            //    Console.WriteLine("no se pudo borrar");
            //}

            List<Televisor> tvo = new List<Televisor>();
            

            //ahora serializamos el datatable
            table.WriteXmlSchema("televisores_esquema.xml");
            table.WriteXml("televisores_dt.xml");

            DataTable otraTabla = new DataTable();
            otraTabla.ReadXmlSchema("televisores_esquema.xml");
            otraTabla.ReadXml("televisores_dt.xml");

            


            Console.Read();
        }
    }
}
