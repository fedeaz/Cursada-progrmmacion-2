﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using System.Xml.Serialization;

namespace BaseDeDatos
{
    public class Televisor
    {
        public int pulgadas;
        public double precio;
        public string marca;
        public string pais;
        public int id;

        

        public Televisor(int Id,int Pulgadas, double Precio, string Marca, string Pais)
        {
            this.pulgadas = Pulgadas;
            this.precio = Precio;
            this.marca = Marca;
            this.pais = Pais;
            this.id = Id;
        }

        public Televisor()
        {
        }

        public bool insertar()
        {
            bool flag = false;

            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

            SqlCommand comando = new SqlCommand();

            string cadena = "INSERT INTO Televisores values(" + this.id + ",'" + this.marca+"',"+ this.precio +","+ this.pulgadas+",'"+this.pais+"')";
            comando.CommandText = cadena;
            
            comando.CommandType = System.Data.CommandType.Text;


            comando.Connection = conexion;

            try
            {
                conexion.Open();
                comando.ExecuteNonQuery();
                conexion.Close();
                flag = true;
            }
            catch (Exception)
            {
                flag = false;
                
            }

            return flag;
        }

        static public bool modificar(Televisor tv)
        {
            bool flag = false;

            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

            SqlCommand comando = new SqlCommand();

            string cadena = "UPDATE Televisores SET  marca = '" + tv.marca + "',precio = " + tv.precio + ", pulgadas = " + tv.pulgadas + ",pais =' " + tv.pais + "' WHERE codigo = " +tv.id  ;
            comando.CommandText = cadena;

            comando.CommandType = System.Data.CommandType.Text;


            comando.Connection = conexion;

            try
            {
                conexion.Open();
                comando.ExecuteNonQuery();
                conexion.Close();
                flag = true;
            }
            catch (Exception)
            {

                flag = false;
            }
            return flag;
        }

        public static bool borrar(Televisor tv)
        {
            bool flag = false;

            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

            SqlCommand comando = new SqlCommand();

            string cadena = "DELETE Televisores WHERE [codigo] = " + tv.id; 
            comando.CommandText = cadena;

            comando.CommandType = System.Data.CommandType.Text;


            comando.Connection = conexion;

            try
            {
                conexion.Open();

                comando.ExecuteNonQuery();

                conexion.Close();
                flag = true;
            }
            catch (Exception)
            {

                flag = false;
            }
            return flag;
        }

        public static List<Televisor> TraerTodos()
        {
            List<Televisor> televiosres = new List<Televisor>();
            try
            {   
            

            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

            SqlCommand comando = new SqlCommand();
            comando.CommandText = "select * from Televisores";

            comando.CommandType = System.Data.CommandType.Text;//recibe un enum

            comando.Connection = conexion;//recibe un obj tipo sql conection

            //se conecta a la base de datos
            conexion.Open();

            SqlDataReader lector = comando.ExecuteReader();

            while (lector.Read())
            {
                //Console.WriteLine(lector[0] + "-" + lector[1] + "-" + lector[2] + "-" + lector[3] + "-" + lector[4]);
                televiosres.Add(new Televisor(lector.GetInt32(0), lector.GetInt32(3), lector.GetDouble(2), lector.GetString(1), lector.GetString(4)));
            }


            //se desconecta de la base de datos
            conexion.Close();


            }
            catch (Exception)
            {

                return null;
            }
            return televiosres ;
        }

        //public static Televisor TraerUno(int a)


    }
}
