﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using System.Xml.Serialization;

namespace BaseDeDatos
{
    public class Televisor
    {
        public int pulgadas;
        public double precio;
        public string marca;
        public string pais;
        public int id;

        

        public Televisor(int Id,int Pulgadas, double Precio, string Marca, string Pais)
        {
            this.pulgadas = Pulgadas;
            this.precio = Precio;
            this.marca = Marca;
            this.pais = Pais;
            this.id = Id;
        }

        public Televisor()
        {
        }

        public bool insertar()
        {
            bool flag = false;

            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

            SqlCommand comando = new SqlCommand();

            string cadena = "INSERT INTO Televisores values(" + this.id + ",'" + this.marca+"',"+ this.precio +","+ this.pulgadas+",'"+this.pais+"')";
            comando.CommandText = cadena;
            
            comando.CommandType = System.Data.CommandType.Text;


            comando.Connection = conexion;

            try
            {
                conexion.Open();
                comando.ExecuteNonQuery();
                conexion.Close();
                flag = true;
            }
            catch (Exception)
            {
                flag = false;
                
            }

            return flag;
        }
   

    }
}
