﻿namespace ejercicioClase04
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.BotonSaludo = new System.Windows.Forms.Button();
            this.LableMensaje = new System.Windows.Forms.Label();
            this.BotonDespedida = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // BotonSaludo
            // 
            this.BotonSaludo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BotonSaludo.Location = new System.Drawing.Point(185, 31);
            this.BotonSaludo.Name = "BotonSaludo";
            this.BotonSaludo.Size = new System.Drawing.Size(92, 42);
            this.BotonSaludo.TabIndex = 1;
            this.BotonSaludo.Text = "Saludar";
            this.BotonSaludo.UseVisualStyleBackColor = true;
            this.BotonSaludo.Click += new System.EventHandler(this.BotonSaludo_Click);
            // 
            // LableMensaje
            // 
            this.LableMensaje.AutoSize = true;
            this.LableMensaje.Location = new System.Drawing.Point(43, 60);
            this.LableMensaje.Name = "LableMensaje";
            this.LableMensaje.Size = new System.Drawing.Size(35, 13);
            this.LableMensaje.TabIndex = 2;
            this.LableMensaje.Text = "label1";
            // 
            // BotonDespedida
            // 
            this.BotonDespedida.Location = new System.Drawing.Point(185, 125);
            this.BotonDespedida.Name = "BotonDespedida";
            this.BotonDespedida.Size = new System.Drawing.Size(92, 40);
            this.BotonDespedida.TabIndex = 3;
            this.BotonDespedida.Text = "Despedida";
            this.BotonDespedida.UseVisualStyleBackColor = true;
            this.BotonDespedida.Click += new System.EventHandler(this.BotonDespedida_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(310, 273);
            this.Controls.Add(this.BotonDespedida);
            this.Controls.Add(this.LableMensaje);
            this.Controls.Add(this.BotonSaludo);
            this.Name = "Form1";
            this.Text = "Clase04";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Click += new System.EventHandler(this.Form1_Click);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Button BotonSaludo;
        private System.Windows.Forms.Label LableMensaje;
        private System.Windows.Forms.Button BotonDespedida;
    }
}

