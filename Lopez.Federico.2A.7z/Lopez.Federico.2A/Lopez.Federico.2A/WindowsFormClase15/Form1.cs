﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormClase15
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void MiManejadorClick(object a,EventArgs b)
        {
            MessageBox.Show(((Control)a).Name);
        }

        public void OtroManejadorClick(object a, EventArgs b)
        {
            //quita le manejador de eventos del button2, para evitar un manejador de evento es similar a agregarlo, en vez de += es -=
            this.button2.Click -= new EventHandler(MiManejadorClick);

            //le agrego el manejador de eventos al boton click tel button1 nuevamente
            //va a mostrar 2 veces el button1
            this.button1.Click += new EventHandler(MiManejadorClick);
        }


        //primer parametro es el objeto, segundo parametro contiene info
        public void CambiarFondo(object a, EventArgs b)
        {
            //cambia el color de fondo del control que recibe como parametro(que probocò el evento)
            ((Control)a).BackColor = Color.Green;
        }

        public void ManejadorCentral(object a, EventArgs b)
        {

            this.button1.Click -= new EventHandler(MiManejadorClick);
            this.button1.Click -= new EventHandler(ManejadorCentral);
            this.button2.Click += new EventHandler(MiManejadorClick);
            this.button2.Click += new EventHandler(ManejadorCentral);

            // this.button2.Click += new EventHandler(MiManejadorClick);

            //this.textBox1.Click += new EventHandler(MiManejadorClick);



        }


        //hacer un delegado que vincule mi manejador y el evento del click del boton
        //asociar al evento click del boton con el delegado para que apunte a miManejador
        private void Form1_Load(object sender, EventArgs e)
        {
            //muestra quien disparò ese evento
              // this.button1.Click += new EventHandler(MiManejadorClick);

            //muestra quien disparò ese evento
             // this.button2.Click += new EventHandler(MiManejadorClick);

            //muestra quien disparò ese evento(INDEPENDIENTE DEL TIPO DE OBJETO, SIEMPRE QUE TENGA LA MISMA FIRMA PUEDO ASIGNAR EL MISMO MANEJADOR)
             // this.textBox1.Click += new EventHandler(MiManejadorClick);

            //solo con this porque yo soy el form
            //quitè de la lista de inbocaciòn el button 2
             // this.Click += new EventHandler(OtroManejadorClick);

            //asigno el cambio de fondo
            //se puede asignar varios manejadores a un evento (este muestra y cambia el color de fondo)
              //this.button1.Click += new EventHandler(CambiarFondo);

            this.button1.Click += new EventHandler(MiManejadorClick);
            this.button1.Click += new EventHandler(ManejadorCentral);
            this.button2.Click += new EventHandler(ManejadorCentral);


        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.button1.Click -= new EventHandler(MiManejadorClick);
            this.button2.Click -= new EventHandler(MiManejadorClick);
            this.textBox1.Click -= new EventHandler(MiManejadorClick);
            this.Click -= new EventHandler(OtroManejadorClick);
            this.button1.Click -= new EventHandler(CambiarFondo);
            //lo saco 2 veces porque si antes de tocar el button3 toco el formulario muestra una vez
            this.button1.Click -= new EventHandler(MiManejadorClick);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
