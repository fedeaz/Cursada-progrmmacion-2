﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio00
{
    class Program
    {
        static void Main(string[] args)
        {
            string nombre = Console.ReadLine();
            //string edad =  Console.ReadLine();
            //int.Parse(edad);
            //Console.WriteLine("Ingrese nombre y edad");
            int edad = int.Parse(Console.ReadLine());
            Console.WriteLine("{0},{1}",nombre,edad);
            Console.ReadLine();
        }
    }
}
