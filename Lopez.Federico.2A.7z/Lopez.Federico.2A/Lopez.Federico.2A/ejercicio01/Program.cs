﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio01
{
    class Program
    {
        static void Main(string[] args)
        {
            int numeros = 0;
            int max = 0;
            int min = 0;
            int acum = 0;
            bool flag=true;
            float prom;


            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("ingrese un numero");
                numeros = int.Parse(Console.ReadLine());

                if(flag)
                {
                    max = min = numeros;
                    flag = false;
                }

                if(numeros>max)
                {
                    max = numeros;
                }
                else if(numeros<min)
                {
                    min = numeros;
                }
                acum = acum + numeros;
                
            }
            prom = (float)(acum / 5.0);

            Console.WriteLine("El numero minimo es {0} \n el numero maximo es {1} \n el promedio es: {2:0.00}", min, max,prom);
            Console.ReadLine();

        }
    }
}
