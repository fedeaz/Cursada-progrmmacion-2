﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.AdministradorArchivos;

namespace Preuba.clase._12
{
    class Program
    {
        static void Main(string[] args)
        {
            string a;
            string b = @"D:\Mis Documentos\nuevo.txt";

            string c = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            c += @"\otroNuevo";

            
            string d = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures) + @"\otroNuevo"; //apunta a la carpeta fotos en cualquier equipo

            string e = AppDomain.CurrentDomain.BaseDirectory + @"\otroNuvo"; //apunta el .exe

            if (AdministradorArchivos.Escribir(b, "Hola Mundo")) ;
            {
                Console.WriteLine("se guardo con exito");
            }

            if (AdministradorArchivos.Escribir(c, "Hola Mundo")) ;
            {
                Console.WriteLine("se guardo con exito");
            }

            if (AdministradorArchivos.Escribir(d, "Hola Mundo")) ;
            {
                Console.WriteLine("se guardo con exito");
            }
        }
    }
}
