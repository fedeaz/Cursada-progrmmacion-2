﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicioClase02
{
    class Program
    {
        static void Main(string[] args)
        {
            Entidades.Sello.mensaje = "Federico";
            Entidades.Sello.color = ConsoleColor.Green;
            Console.WriteLine(Entidades.Sello.imprimir());
           // Console.ReadLine();
            Entidades.Sello.imprimirEnColor();
            Entidades.Sello.imprimir();
            Console.ReadLine();

            /* Entidades.Sello.borrar();
             Console.WriteLine(Entidades.Sello.imprimir());
             Console.ReadLine();*/

            


        }
    }
}
