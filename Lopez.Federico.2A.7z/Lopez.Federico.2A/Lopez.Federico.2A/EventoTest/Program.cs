﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesA;



namespace EventoTest
{
    public class Program
    {
        public static void pruebaEvento()
        { Console.WriteLine("se inserto la base de datos"); }

        public void pruebaEvento2()
        { Console.WriteLine("estoy dentro del segundo metodo"); }

        public void eventoTv(Televisor tv, TVEventsArt a)
        {
            Console.WriteLine("codigo = " + tv.id + " marca = " + tv.marca + " precio = " + tv.precio + " pulgdas = " + tv.pulgadas + " pais = " + tv.pais);
            Console.WriteLine(a.Fecha);
        }

        static void Main(string[] args)
        {
            Televisor tv1 = new Televisor(15, 30, 60, "Senty", "España");
            tv1.miEvento += new Televisor.MiDelegado(pruebaEvento);

            tv1.miEvento += new Televisor.MiDelegado(new Program().pruebaEvento2);

            tv1.EventoTv += new Televisor.DelegadoTv(new Program().eventoTv);



            tv1.insertar();

            


            Console.ReadKey();


            
        }
    }
}
