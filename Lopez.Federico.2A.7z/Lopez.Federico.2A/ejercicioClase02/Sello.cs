﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Sello
    {
        public static string mensaje;

        public static ConsoleColor color;

        public static string imprimir()
        {
            string cad;
            string error;
            if(Sello.TryParce(Sello.mensaje,out cad))
            {
                Sello.mensaje = cad;
                Sello.mensaje= ArmarFormatoMensaje();
            }
            else
            {
                Console.WriteLine("Error, mensaje vacio");
            }
            
            return Sello.mensaje;
        }
        public static void  borrar()
        {
            Sello.mensaje = "";
        }

        public static void imprimirEnColor()
        {
            Console.BackgroundColor = Sello.color;
            Console.WriteLine(Sello.imprimir());
            Console.BackgroundColor = ConsoleColor.Black;
        }

        private static string ArmarFormatoMensaje()
        {
            int tam;
            string asteriscos = "";
            string reto="";
            tam = Sello.mensaje.Length;
            
            for (int i=0;i<tam+2;i++)
            {
                asteriscos = asteriscos + "*";
            }
            asteriscos += "\n";

            reto = asteriscos +"*" + Sello.mensaje + "*\n"+asteriscos ;


            return reto;
        }

        private static Boolean TryParce (string A, out string B)
        {
            Boolean reto = false;
            B = "";
            if(A.Length>0 )
                {
                    B = A;
                   reto = true;
                }
            return reto;
        }
        
    }
}
