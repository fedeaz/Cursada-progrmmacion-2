﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicioClase05
{
    class Tinta
    {
        #region atributos
        private ConsoleColor _color;
        private ETipoTinta _tipo;
        #endregion

        private string Mostrar()
        {
            string retorno = "";
            retorno += this._tipo;
            retorno += " - ";
            retorno += this._color;

            return retorno;
        }
        public static string Mostrar(Tinta a)
        {

            return a.Mostrar();
        }





        #region constructor

        public Tinta()
        {
            this._color = ConsoleColor.Blue;
            this._tipo = ETipoTinta.ConBrillitos;
        }

        public Tinta(ConsoleColor color) : this()
        {
            this._color = color;
        }

        public Tinta(ETipoTinta tinta) : this()
        {
            this._tipo = tinta;
        }

        public Tinta(ConsoleColor color, ETipoTinta tinta)
        {
            this._color = color;
            this._tipo = tinta;
        }

        public Tinta(ETipoTinta tinta, ConsoleColor color)
        {
            this._color = color;
            this._tipo = tinta;
        }
        #endregion

        #region sobrecarga op
        public static bool operator ==(Tinta a, Tinta b)
        {
            if(a._color == b._color && a._tipo == b._tipo)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public static bool operator !=(Tinta a, Tinta b)
        {
            return !(a==b);
        }
            #endregion
        }
}
