﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clase06
{
    public partial class firmPluma : Form
    {
        public firmPluma()
        {
            InitializeComponent();

            
        }

        private void firmPluma_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmTinta form = new frmTinta();

            form.Show();
        }
    }
}
