﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicioClase05
{
    class Pluma
    {
        #region atributos
        private string _marca;
        private int _cantidad;
        private Tinta _tinta;
        #endregion

        #region constructores
        public Pluma()
        {
            this._marca = "Sin marca";
            this._cantidad = 0;
            this._tinta = null;
        }

        public Pluma(string marcaP) : this()
        {
            this._marca = marcaP;
        }

        public Pluma(string marcaP, Tinta tinta) : this(marcaP)
        {
            this._marca = marcaP;
            this._tinta = tinta;
        }

        public Pluma(string marcaP, int cantidad, Tinta tinta ) :this(marcaP,tinta)
        {
            this._cantidad = cantidad;
            this._tinta = tinta;
            this._marca = marcaP;
        }

        #endregion

        private string Mostrar()
        {
            string retorno = " ";
            retorno += this._marca;
            retorno += " - ";
            retorno += this._cantidad;
            retorno += " - ";
            retorno += Tinta.Mostrar(this._tinta);
            return retorno;
        }

        public static implicit operator  string(Pluma a)
        {
            return a.Mostrar();
        }

        #region sobrecarga op

        public static bool operator == (Pluma a, Tinta b)
        {
            if(a._tinta == b)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public static bool operator !=(Pluma a, Tinta b)
        {
            return !(a == b);
        }

        public static Pluma operator +(Pluma a, Tinta b)
        {
            if(a._tinta == b)
            {
                a._cantidad += 10;

                if(a._cantidad > 100)
                {
                  a._cantidad -=10;
                  
                }
                   
            }
            return a;
        }

        public static Pluma operator -(Pluma a, Tinta b)
        {
            if(a._tinta ==b)
            {
                a._cantidad -= 15;
                if (a._cantidad < 0)
                {
                    a._cantidad += 15;
                }
                    
            }
            return a;
        }

        #endregion
    }
}
