﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio03
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int contador = 1;

            Console.WriteLine("ingrese un numero");
            numero = int.Parse(Console.ReadLine());

            for (int i = 1; i <= numero; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    if (i % j == 0)
                    {
                        contador++;
                    }
                }
                if (contador == 2 || i == 1)
                {
                    Console.WriteLine("{0}  es primo", i);
                }
                contador = 0;
            }
            Console.ReadLine();

        }
    }
}
