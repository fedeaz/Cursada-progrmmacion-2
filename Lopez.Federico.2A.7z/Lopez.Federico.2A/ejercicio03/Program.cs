﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio03
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int a=0;

            Console.WriteLine("ingrese un numero");
            numero = int.Parse(Console.ReadLine());

            for (int i=1;i<(numero + 1);i++)
            {
                if(numero % i == 0)
                {
                    a ++;
                }

                if(a != 2)
                {
                    Console.WriteLine("No primo{0}",i);
                    
                }
                else
                {
                    Console.WriteLine("Numeros primos {0}",i);
                }
                Console.ReadLine();

            }

        }
    }
}
