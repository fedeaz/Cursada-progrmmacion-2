﻿using System;

namespace Entidades.clase07
{
    public class Class1
    {
    }
}
