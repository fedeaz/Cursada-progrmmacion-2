﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.clase07
{
    
    class Paletas
    {
        private Tempera[] _colores;
        private int _cantMaximaElementos;
        #region constructores
        private Paletas():this(5)
        {
        }

        private Paletas(int i)
        {
            this._cantMaximaElementos = i;
            _colores = new Tempera[this._cantMaximaElementos];
        }
        #endregion

        private string mostrar()
        {
            string retorno = " ";
            retorno += this._cantMaximaElementos;
            retorno += "--\n";
            foreach (Tempera item in this._colores)
            {
                retorno += item;
            }

            return retorno;
        }

        public static explicit operator string(Paletas pal)
        {
            return pal.mostrar();
        }
        public static implicit operator Paletas(int i)
        {
            return new Paletas(i);
        }


        public static bool operator ==(Paletas pal, Tempera tep)
        {
            bool retorno = false;

            foreach (Tempera item in pal._colores)
            {
                if(!object.Equals(item,null))
                {
                    if(item == tep)
                    {
                        retorno = true;
                        break;
                    }
                }
            }
            return retorno;
        }

        public static bool operator !=(Paletas pal, Tempera tep)
        {
            return !(pal == tep);
        }


        private int ObtenerIndice()
        {
            int returnAux = -1;
            int i = 0;
            foreach(Tempera item in this._colores)
            {
                if(object.Equals(item, null))
                {
                    returnAux = i;
                    break;
                }
                i++;
            }
            return returnAux;
        }

        private int ObtenerIndice(int i)
        {
            int returnAux = -1;
            foreach (Tempera item in this._colores)
            {
                if (object.Equals(item, null))
                {
                    returnAux = i;
                    break;
                }
                i++;
            }
            return returnAux;
        }


        public static Paletas operator +(Paletas pal,Tempera temp)
        {
            int indice;
            indice = pal.ObtenerIndice();
            if( pal == temp&& indice >-1)
            {

            }

        }
    }
}
