﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.clase07
{
    public class Tempera
    {
        #region atributos
        private sbyte _cantidad;
        private ConsoleColor _color;
        private string _marca;

        #endregion

        #region constructores
        public Tempera(sbyte cant, ConsoleColor color, string marca)
        {
            _cantidad = cant;
            _color = color;
            _marca = marca;
        }

        #endregion
        #region metodos
        private string mostrar()
        {
            string retorno = " ";

            retorno += this._cantidad;
            retorno += "--";
            retorno += this._color;
            retorno += "--";
            retorno += this._marca;
            return retorno;
        }
        #endregion

        #region sobrecargas
        public static implicit operator string(Tempera temp)
        {
            return temp.mostrar();
        }

        public static explicit operator sbyte(Tempera temp)
        {
            return temp._cantidad;
        }

        public static bool operator ==(Tempera temp, Tempera temp2)
        {
            bool retorno = false;
            if(temp._color == temp2._color && temp._marca == temp2._marca)
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Tempera temp,Tempera temp2)
        {
            return !(temp == temp2);
        }

        public static Tempera operator +(Tempera temp, SByte cant)
        {
            temp._cantidad += cant;
            return temp;
        }

        public static Tempera operator +(Tempera temp, Tempera temp2)
        {
            Tempera temp3 = new Tempera(temp._cantidad, temp._color, temp._marca);
            if(temp == temp2 )
            {
                temp3 += temp2._cantidad;
            }
            return temp3;
        }

        //public static Tempera operator -(Tempera temp, Tempera temp2)
        //{
        //    Tempera temp3 = new Tempera(temp._cantidad, temp._color, temp._marca);
        //    if (temp == temp2)
        //    {
        //        temp3 -= temp2._cantidad;
        //    }
        //    return temp3;
        //}

        //public static Tempera operator -(Tempera temp, SByte cant)
        //{
        //    temp._cantidad -= cant;
        //    return temp;
        //}
        #endregion
    }
}
