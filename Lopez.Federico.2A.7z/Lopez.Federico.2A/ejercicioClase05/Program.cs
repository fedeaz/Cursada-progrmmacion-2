﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicioClase05
{
    class Program
    {
        static void Main(string[] args)
        {
            Tinta tint = new Tinta();
            Console.WriteLine(Tinta.Mostrar(tint));
            Console.ReadLine();
        }
    }
}
